import json
from types import SimpleNamespace

from app.agent import MealCalorieAgent
from app.memory import SessionMemory


class FakeCompletions:
    def __init__(self):
        self.calls = 0

    def create(self, **kwargs):
        self.calls += 1
        if self.calls == 1:
            tool_call = SimpleNamespace(
                id="call-1",
                function=SimpleNamespace(
                    name="add_meal",
                    arguments=json.dumps({"food": "banana"}),
                ),
            )
            message = SimpleNamespace(content=None, tool_calls=[tool_call])
        else:
            message = SimpleNamespace(
                content="The banana was added to today's memory.",
                tool_calls=None,
            )
        return SimpleNamespace(choices=[SimpleNamespace(message=message)])


class FakeClient:
    def __init__(self):
        self.chat = SimpleNamespace(completions=FakeCompletions())


def test_llm_agent_executes_tool_loop_and_memory_update():
    memory = SessionMemory(budget=2000)
    agent = MealCalorieAgent(memory=memory, client=FakeClient(), model="test-model")

    result = agent.run("I ate a banana for breakfast.")

    assert result["mode"] == "llm"
    assert memory.total_calories() == 105
    assert any(item.get("tool") == "add_meal" for item in result["trace"])
    assert any(item["action"] == "read_memory_after_tools" for item in result["trace"])


def test_irrelevant_request_is_rejected_by_scope_guard():
    agent = MealCalorieAgent(memory=SessionMemory(), client=FakeClient(), model="test-model")
    result = agent.run("What is the capital of France?")
    assert "outside my scope" in result["answer"]
    assert result["trace"][0]["action"] == "scope_check"
