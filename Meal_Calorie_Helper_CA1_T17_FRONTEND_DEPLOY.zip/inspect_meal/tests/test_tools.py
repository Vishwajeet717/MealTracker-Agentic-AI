from app.memory import SessionMemory
from app.tools import add_meal, lookup_calories


def test_lookup_known_food():
    result = lookup_calories("banana")
    assert result["ok"] is True
    assert result["calories"] == 105


def test_lookup_unknown_food_does_not_fail():
    result = lookup_calories("dragon fruit cheesecake")
    assert result["ok"] is True
    assert result["calories"] > 0
    assert result["estimate_type"] in {"heuristic", "generic_food_fallback"}


def test_add_meal_updates_memory():
    memory = SessionMemory(budget=2000)
    result = add_meal("oatmeal", memory)
    assert result["ok"] is True
    assert memory.total_calories() == 158


def test_add_meal_unknown_food_still_tracks_estimate():
    memory = SessionMemory(budget=2000)
    result = add_meal("dragon fruit cheesecake", memory)
    assert result["ok"] is True
    assert memory.total_calories() > 0
