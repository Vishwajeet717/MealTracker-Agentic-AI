from app.memory import SessionMemory


def test_memory_tracks_meals_and_remaining_budget():
    memory = SessionMemory(budget=2000)
    memory.add_meal("oatmeal", 158)
    memory.add_meal("banana", 105)

    summary = memory.get_today_summary()

    assert summary["consumed"] == 263
    assert summary["remaining"] == 1737
    assert len(summary["meals"]) == 2
