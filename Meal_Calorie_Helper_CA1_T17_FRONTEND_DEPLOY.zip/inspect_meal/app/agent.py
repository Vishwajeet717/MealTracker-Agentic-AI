"""Groq-powered agent with local function/tool calling."""

from __future__ import annotations

import json
import os
import re
from typing import Any

from .config import get_setting
from .memory import SessionMemory
from .tools import add_meal, get_memory_summary, lookup_calories

try:
    from groq import Groq
except ImportError:  # pragma: no cover
    Groq = None


SYSTEM_PROMPT = """
You are Meal Calorie Helper, a helpful AI agent for meal, food, nutrition,
calorie-budget, and everyday eating questions.

This is an educational/informational application. It is not medical advice.

The application has exactly two assignment tools:
1. lookup_calories(food)
2. add_meal(food)

SCOPE:
- Help with food, meals, snacks, calories, calorie budgets, simple nutrition
  information, meal tracking, and questions about what the user ate or plans
  to eat.
- You may answer ordinary food/meal/nutrition questions directly when no tool
  is needed.
- Do not answer unrelated domains such as politics, coding, homework, sports,
  weather, or general trivia. For clearly unrelated requests, politely say
  that you are specialized in meal/food/calorie assistance.

AGENT BEHAVIOR:
- You are an agent, not a one-shot chatbot.
- Decide what action is needed from the user's goal.
- Use tool results to decide what to do next.
- Before adding a food the user actually ate, obtain calorie information using
  lookup_calories first when necessary.
- Use add_meal only when the user is saying they actually ate/consumed the food,
  not when they are merely asking whether they can eat it.
- For planned snacks, use lookup_calories and compare the combined planned
  calories with the current remaining budget.
- Never claim that a meal was added unless add_meal returned success.
- Unknown or unusual food names are still valid food requests. Use
  lookup_calories; it may return an approximate heuristic estimate. Clearly
  label estimates as approximate when relevant.
- Do not reject a food request merely because the exact dish is not in the
  local table.
- Use the supplied application memory whenever the answer depends on today's
  meals, budget, consumed calories, or remaining calories.
- Keep responses concise but useful.
"""


# Clearly unrelated requests can be rejected before spending a model/tool turn.
# This list is intentionally conservative so normal food questions continue to
# reach the LLM.
OBVIOUSLY_IRRELEVANT_PATTERNS = [
    r"\bwrite\s+(?:me\s+)?(?:python|java|c\+\+|javascript)\b",
    r"\bdebug\b.*\bcode\b",
    r"\bwhat(?:'s| is)\s+the\s+capital\s+of\b",
    r"\bwho\s+won\b.*\b(?:match|game|tournament)\b",
    r"\bweather\b",
    r"\bpolitics?\b",
    r"\bprime\s+minister\b",
    r"\bsolve\s+(?:this\s+)?(?:math|equation|integral)\b",
    r"\bwrite\s+(?:an\s+)?essay\b",
]


def _is_obviously_irrelevant(text: str) -> bool:
    lower = text.lower()
    return any(re.search(pattern, lower) for pattern in OBVIOUSLY_IRRELEVANT_PATTERNS)


class MealCalorieAgent:
    """LLM-driven agent for T17 using Groq local tool calling."""

    MAX_STEPS = 10

    def __init__(
        self,
        memory: SessionMemory | None = None,
        client: Any | None = None,
        model: str | None = None,
    ) -> None:
        self.memory = memory or SessionMemory()
        self.model = model or get_setting("GROQ_MODEL", "openai/gpt-oss-120b")
        self.client = client if client is not None else self._create_client_if_configured()

    def _create_client_if_configured(self) -> Any | None:
        if Groq is None:
            return None

        api_key = get_setting("GROQ_API_KEY")
        if not api_key:
            return None
        return Groq(api_key=api_key)

    def _require_client(self) -> None:
        if self.client is None:
            raise RuntimeError(
                "Groq is not configured. Create a .env file and set GROQ_API_KEY, "
                "then install the dependencies with: pip install -r requirements.txt"
            )

    def _tool_schemas(self) -> list[dict[str, Any]]:
        return [
            {
                "type": "function",
                "function": {
                    "name": "lookup_calories",
                    "description": (
                        "Look up or generate a clearly labeled approximate educational "
                        "calorie estimate for a food. This should be used for normal food "
                        "names even when the exact dish is not in the local table."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "food": {
                                "type": "string",
                                "description": "Food, dish, snack, or drink to look up.",
                            }
                        },
                        "required": ["food"],
                        "additionalProperties": False,
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "add_meal",
                    "description": (
                        "Record a food the user says they actually ate/consumed in today's "
                        "meal memory. It obtains an approximate calorie value and updates totals."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "food": {
                                "type": "string",
                                "description": "Food or dish the user says they ate.",
                            }
                        },
                        "required": ["food"],
                        "additionalProperties": False,
                    },
                },
            },
        ]

    def _execute_tool(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        if name == "lookup_calories":
            return lookup_calories(str(args.get("food", "")))
        if name == "add_meal":
            return add_meal(str(args.get("food", "")), self.memory)
        return {"ok": False, "error": f"Unknown tool: {name}"}

    def _extract_budget(self, user_text: str) -> None:
        """Capture an explicit budget as application state."""
        match = re.search(
            r"(?:calorie\s+)?(?:budget|limit)\s*(?:is|of|=)?\s*(\d+(?:\.\d+)?)",
            user_text.lower(),
        )
        if match:
            self.memory.set_budget(float(match.group(1)))

    def _memory_context(self) -> dict[str, Any]:
        return get_memory_summary(self.memory)

    def _build_messages(self, user_text: str) -> list[dict[str, Any]]:
        return [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "system",
                "content": (
                    "Current application memory for this turn:\n"
                    + json.dumps(self._memory_context(), indent=2)
                ),
            },
            {"role": "user", "content": user_text},
        ]

    def _out_of_scope_result(self, user_text: str) -> dict[str, Any]:
        answer = (
            "I'm the Meal Calorie Helper, so I can help with meals, food, calories, "
            "nutrition, and your daily calorie budget. That request is outside my scope."
        )
        return {
            "answer": answer,
            "trace": [
                {
                    "step": 0,
                    "action": "scope_check",
                    "decision_source": "application_guard",
                    "result": "irrelevant_request",
                    "user_text": user_text,
                },
                {
                    "step": 1,
                    "action": "final_answer",
                    "decision_source": "application_guard",
                },
            ],
            "memory": self._memory_context(),
            "mode": "llm",
        }

    def run(self, user_text: str) -> dict[str, Any]:
        """Run one user turn through the LLM/tool loop."""
        if not user_text.strip():
            return {
                "answer": "Please enter a meal, food, calorie, or nutrition question.",
                "trace": [],
                "memory": self._memory_context(),
                "mode": "llm",
            }

        if _is_obviously_irrelevant(user_text):
            return self._out_of_scope_result(user_text)

        self._require_client()
        self._extract_budget(user_text)

        messages = self._build_messages(user_text)
        trace: list[dict[str, Any]] = [
            {
                "step": 0,
                "action": "read_memory_context",
                "decision_source": "application_memory",
                "result": self._memory_context(),
            }
        ]

        for step in range(1, self.MAX_STEPS + 1):
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                tools=self._tool_schemas(),
                tool_choice="auto",
                temperature=0,
            )
            msg = response.choices[0].message

            if not msg.tool_calls:
                final_answer = msg.content or "I could not produce an answer."
                trace.append(
                    {
                        "step": step,
                        "action": "final_answer",
                        "decision_source": "LLM",
                    }
                )
                return {
                    "answer": final_answer,
                    "trace": trace,
                    "memory": self._memory_context(),
                    "mode": "llm",
                }

            assistant_tool_calls: list[dict[str, Any]] = []
            parsed_calls: list[tuple[Any, dict[str, Any]]] = []

            for call in msg.tool_calls:
                try:
                    args = json.loads(call.function.arguments or "{}")
                except json.JSONDecodeError:
                    args = {}

                parsed_calls.append((call, args))
                assistant_tool_calls.append(
                    {
                        "id": call.id,
                        "type": "function",
                        "function": {
                            "name": call.function.name,
                            "arguments": json.dumps(args),
                        },
                    }
                )

            messages.append(
                {
                    "role": "assistant",
                    "content": msg.content,
                    "tool_calls": assistant_tool_calls,
                }
            )

            for call, args in parsed_calls:
                tool_name = call.function.name
                result = self._execute_tool(tool_name, args)

                trace.append(
                    {
                        "step": step,
                        "action": "tool_call",
                        "decision_source": "LLM",
                        "tool": tool_name,
                        "args": args,
                        "result": result,
                    }
                )

                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": call.id,
                        "content": json.dumps(result),
                    }
                )

            latest_memory = self._memory_context()
            trace.append(
                {
                    "step": step,
                    "action": "read_memory_after_tools",
                    "decision_source": "application_memory",
                    "result": latest_memory,
                }
            )
            messages.append(
                {
                    "role": "system",
                    "content": (
                        "Updated application memory after the latest tool round:\n"
                        + json.dumps(latest_memory, indent=2)
                    ),
                }
            )

        trace.append(
            {
                "step": self.MAX_STEPS,
                "action": "agent_loop_limit",
                "decision_source": "application",
            }
        )
        return {
            "answer": (
                "I reached the maximum tool-call steps before completing the request. "
                "Please try a simpler meal or calorie question."
            ),
            "trace": trace,
            "memory": self._memory_context(),
            "mode": "llm",
        }
