"""Streamlit frontend for the Meal Calorie Helper."""

from __future__ import annotations

import streamlit as st

from app.agent import MealCalorieAgent
from app.config import get_setting


st.set_page_config(
    page_title="Meal Calorie Helper",
    page_icon="🍎",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .hero {
        padding: 1.2rem 1.4rem;
        border-radius: 18px;
        border: 1px solid rgba(128,128,128,.25);
        margin-bottom: 1rem;
    }
    .muted { opacity: .72; }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    '<div class="hero"><h1>🍎 Meal Calorie Helper</h1>'
    '<div class="muted">CSE476 CA1 • T17 • Groq AI Agent • Informational only</div></div>',
    unsafe_allow_html=True,
)

if "agent" not in st.session_state:
    st.session_state.agent = MealCalorieAgent()
if "messages" not in st.session_state:
    st.session_state.messages = []

agent: MealCalorieAgent = st.session_state.agent
memory = agent.memory
summary = memory.get_today_summary()

with st.sidebar:
    st.header("Today's plan")
    budget = st.number_input(
        "Daily calorie budget",
        min_value=1,
        value=int(memory.budget or 2000),
        step=50,
    )
    if st.button("Update budget", use_container_width=True):
        memory.set_budget(float(budget))
        st.rerun()

    st.divider()
    st.caption("Current totals")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Consumed", f"{summary['consumed']:.0f}")
    with col2:
        remaining = summary["remaining"]
        st.metric("Remaining", f"{remaining:.0f}" if remaining is not None else "—")

    st.divider()
    st.caption("Today's meals")
    if not memory.meals:
        st.info("No meals logged yet.")
    else:
        for meal in memory.meals:
            st.write(f"**{meal.food}** — {meal.calories:.0f} kcal")

    st.divider()
    st.caption("Model")
    st.code(get_setting("GROQ_MODEL", "openai/gpt-oss-120b"), language="text")

left, right = st.columns([1.7, 1])

with left:
    st.subheader("Chat with your meal agent")

    if not st.session_state.messages:
        st.info(
            "Try: “I had dosa and sambar for breakfast.”  "
            "Or: “Can I have yogurt and an apple as a snack?”"
        )

    for item in st.session_state.messages:
        with st.chat_message(item["role"]):
            st.markdown(item["content"])
            if item.get("trace"):
                with st.expander("Show agent trace"):
                    for event in item["trace"]:
                        st.json(event)

    prompt = st.chat_input("Ask about meals, food, calories, or your budget...")
    if prompt:
        st.session_state.messages.append(
            {"role": "user", "content": prompt}
        )

        try:
            result = agent.run(prompt)
        except Exception as exc:
            result = {
                "answer": f"The agent could not run: {exc}",
                "trace": [],
                "memory": memory.get_today_summary(),
            }

        st.session_state.messages.append(
            {
                "role": "assistant",
                "content": result["answer"],
                "trace": result["trace"],
            }
        )
        st.rerun()

with right:
    st.subheader("Agent proof")
    st.caption("The expandable trace shows LLM decisions, tool calls, tool results, and memory updates.")

    if st.session_state.messages:
        latest = st.session_state.messages[-1]
        if latest.get("trace"):
            for event in latest["trace"]:
                action = event.get("action", "event")
                if action == "tool_call":
                    st.success(f"LLM → {event.get('tool')}")
                elif action == "final_answer":
                    st.info("LLM → final answer")
                elif action.startswith("read_memory"):
                    st.write("🧠 Memory read")
                elif action == "scope_check":
                    st.warning("Scope guard → irrelevant request")
    else:
        st.write("Send a message to see the agent trace.")
