from dataclasses import dataclass, field
from datetime import date
from typing import Any


@dataclass
class Meal:
    food: str
    calories: float


@dataclass
class SessionMemory:
    budget: float | None = None
    day: str = field(default_factory=lambda: date.today().isoformat())
    meals: list[Meal] = field(default_factory=list)

    def set_budget(self, budget: float) -> None:
        if budget <= 0:
            raise ValueError("Calorie budget must be greater than zero.")
        self.budget = float(budget)

    def add_meal(self, food: str, calories: float) -> Meal:
        meal = Meal(food=food, calories=float(calories))
        self.meals.append(meal)
        return meal

    def total_calories(self) -> float:
        return sum(m.calories for m in self.meals)

    def remaining_calories(self) -> float | None:
        if self.budget is None:
            return None
        return self.budget - self.total_calories()

    def get_today_summary(self) -> dict[str, Any]:
        return {
            "day": self.day,
            "budget": self.budget,
            "meals": [{"food": m.food, "calories": m.calories} for m in self.meals],
            "consumed": self.total_calories(),
            "remaining": self.remaining_calories(),
        }
