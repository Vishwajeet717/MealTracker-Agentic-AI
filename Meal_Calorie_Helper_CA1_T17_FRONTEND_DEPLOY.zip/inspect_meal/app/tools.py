"""The two assignment tools for the Meal Calorie Helper."""

from __future__ import annotations

import re
from typing import Any

from .memory import SessionMemory

# Exact/near-exact entries for common foods, including Indian foods so the
# project is useful in a realistic classroom demo.
CALORIE_DB: dict[str, float] = {
    "apple": 95,
    "banana": 105,
    "orange": 62,
    "mango": 135,
    "guava": 68,
    "grapes": 104,
    "watermelon": 46,
    "papaya": 59,
    "oatmeal": 158,
    "porridge": 158,
    "yogurt": 120,
    "curd": 100,
    "greek yogurt": 100,
    "toast": 80,
    "bread": 80,
    "egg": 78,
    "eggs": 156,
    "2 eggs": 156,
    "3 eggs": 234,
    "boiled egg": 78,
    "omelette": 180,
    "chicken sandwich": 400,
    "sandwich": 350,
    "grilled chicken": 300,
    "chicken": 250,
    "rice": 206,
    "chicken rice": 500,
    "fried rice": 450,
    "biryani": 520,
    "chicken biryani": 560,
    "dal": 180,
    "lentils": 180,
    "salad": 150,
    "milk": 122,
    "coffee": 5,
    "tea": 2,
    "chapati": 100,
    "chapathi": 100,
    "roti": 100,
    "2 rotis": 200,
    "paratha": 220,
    "naan": 260,
    "dosa": 170,
    "masala dosa": 300,
    "idli": 60,
    "2 idlis": 120,
    "sambar": 120,
    "poha": 250,
    "upma": 250,
    "pav bhaji": 400,
    "vada pav": 290,
    "samosa": 260,
    "pakora": 220,
    "paneer": 265,
    "paneer tikka": 280,
    "rajma": 210,
    "chole": 240,
    "chana masala": 240,
    "curd rice": 300,
    "khichdi": 280,
    "pasta": 380,
    "noodles": 380,
    "ramen": 450,
    "pizza": 285,
    "pizza slice": 285,
    "burger": 500,
    "fries": 365,
    "french fries": 365,
    "ice cream": 210,
    "cake": 350,
    "cheesecake": 400,
    "chocolate": 150,
    "cookie": 120,
    "cookies": 240,
    "peanut butter": 95,
    "peanut butter toast": 220,
    "nuts": 170,
    "almonds": 164,
    "protein shake": 180,
}

# Keyword based per-serving estimates. These are deliberately approximate and
# let the assistant handle food names that are not exact dictionary matches.
HEURISTIC_ESTIMATES: list[tuple[tuple[str, ...], float, str]] = [
    (("cheesecake",), 400, "dessert heuristic"),
    (("cake", "pastry", "brownie", "donut", "doughnut"), 350, "dessert heuristic"),
    (("pizza",), 285, "pizza heuristic"),
    (("burger", "hamburger"), 500, "burger heuristic"),
    (("sandwich", "wrap", "roll"), 350, "sandwich heuristic"),
    (("biryani",), 520, "rice-meal heuristic"),
    (("fried rice",), 450, "rice-meal heuristic"),
    (("rice",), 206, "rice heuristic"),
    (("dosa",), 170, "South-Indian meal heuristic"),
    (("idli",), 60, "South-Indian meal heuristic"),
    (("roti", "chapati", "chapathi"), 100, "flatbread heuristic"),
    (("paratha",), 220, "flatbread heuristic"),
    (("naan",), 260, "flatbread heuristic"),
    (("dal", "lentil", "lentils"), 180, "legume heuristic"),
    (("paneer",), 265, "paneer heuristic"),
    (("noodle", "noodles", "ramen"), 400, "noodle heuristic"),
    (("pasta",), 380, "pasta heuristic"),
    (("salad",), 150, "salad heuristic"),
    (("soup",), 140, "soup heuristic"),
    (("egg", "eggs", "omelette"), 100, "egg heuristic"),
    (("chicken",), 280, "chicken heuristic"),
    (("fish", "salmon", "tuna"), 250, "fish heuristic"),
    (("yogurt", "curd"), 120, "dairy heuristic"),
    (("milk",), 122, "dairy heuristic"),
    (("oat", "oatmeal", "porridge"), 160, "breakfast heuristic"),
    (("fruit",), 90, "fruit heuristic"),
    (("banana",), 105, "fruit heuristic"),
    (("apple",), 95, "fruit heuristic"),
    (("smoothie",), 220, "beverage heuristic"),
    (("shake",), 220, "beverage heuristic"),
    (("coffee",), 5, "beverage heuristic"),
    (("tea",), 5, "beverage heuristic"),
    (("samosa",), 260, "snack heuristic"),
    (("pakora",), 220, "snack heuristic"),
    (("chips", "crisps"), 150, "snack heuristic"),
    (("cookie", "cookies"), 120, "snack heuristic"),
    (("chocolate",), 150, "snack heuristic"),
]


def _normalize(food: str) -> str:
    return " ".join(food.strip().lower().split())


def _quantity_multiplier(food: str) -> float:
    """Apply simple count multipliers such as '2 eggs' or '3 idlis'."""
    match = re.match(r"^(\d+)\s+(.+)$", _normalize(food))
    if not match:
        return 1.0
    quantity = int(match.group(1))
    return max(1, min(quantity, 10))


def _estimate_from_keywords(key: str) -> tuple[float, str] | None:
    for keywords, calories, source in HEURISTIC_ESTIMATES:
        if any(keyword in key for keyword in keywords):
            return calories * _quantity_multiplier(key), source
    return None


def lookup_calories(food: str) -> dict[str, Any]:
    """Look up or estimate calories for a food without failing on normal food names.

    Exact dictionary matches return an exact local educational estimate.
    Unmatched food names are handled with a transparent heuristic estimate so
    ordinary meal/food requests do not fail just because the exact dish is not
    in the small demo dataset.
    """
    key = _normalize(food)
    if not key:
        return {"ok": False, "food": food, "error": "Food name is empty."}

    if key in CALORIE_DB:
        return {
            "ok": True,
            "food": food,
            "calories": CALORIE_DB[key],
            "estimate_type": "exact_local",
            "source": "local educational dataset",
        }

    estimated = _estimate_from_keywords(key)
    if estimated is not None:
        calories, source = estimated
        return {
            "ok": True,
            "food": food,
            "calories": round(calories, 1),
            "estimate_type": "heuristic",
            "confidence": "approximate",
            "source": source,
            "note": "Approximate educational estimate; actual calories vary by recipe and portion size.",
        }

    # Final food-safe fallback. The agent should not fail merely because an
    # unfamiliar food name was supplied. We explicitly label this as a low-
    # confidence generic meal estimate instead of presenting it as exact data.
    return {
        "ok": True,
        "food": food,
        "calories": 250.0,
        "estimate_type": "generic_food_fallback",
        "confidence": "low",
        "source": "generic educational fallback",
        "note": (
            "No exact local entry was available, so this is a low-confidence "
            "generic estimate. Ask for portion size or a specific preparation "
            "for a more useful estimate."
        ),
    }


def add_meal(food: str, memory: SessionMemory) -> dict[str, Any]:
    """Add a food the user says they ate to today's memory."""
    looked_up = lookup_calories(food)
    if not looked_up["ok"]:
        return {"ok": False, "food": food, "error": looked_up["error"]}

    meal = memory.add_meal(
        food=str(looked_up["food"]),
        calories=float(looked_up["calories"]),
    )
    summary = memory.get_today_summary()

    return {
        "ok": True,
        "added": {
            "food": meal.food,
            "calories": meal.calories,
            "estimate_type": looked_up.get("estimate_type"),
            "confidence": looked_up.get("confidence", "normal"),
        },
        "consumed": summary["consumed"],
        "remaining": summary["remaining"],
        "meal_count": len(memory.meals),
    }


def get_memory_summary(memory: SessionMemory) -> dict[str, Any]:
    """Read today's stored meal memory for the agent."""
    return memory.get_today_summary()
