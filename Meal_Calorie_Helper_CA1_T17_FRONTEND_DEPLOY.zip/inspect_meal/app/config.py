"""Configuration helpers for local and Streamlit deployment environments."""

from __future__ import annotations

import os

from dotenv import load_dotenv

load_dotenv()


def get_setting(name: str, default: str | None = None) -> str | None:
    """Read a setting from environment variables, then Streamlit secrets."""
    value = os.getenv(name)
    if value:
        return value

    # Streamlit Cloud exposes secrets through st.secrets. Keep this import
    # optional so the CLI and tests do not need Streamlit to be imported.
    try:
        import streamlit as st

        secret_value = st.secrets.get(name)
        if secret_value:
            return str(secret_value)
    except Exception:
        pass

    return default
