from dotenv import load_dotenv

from app.agent import MealCalorieAgent

load_dotenv()


def print_trace(trace: list[dict]) -> None:
    print("\nAgent Trace:")
    print("-" * 70)
    for item in trace:
        print(item)
    print("-" * 70)


def main() -> None:
    print("Meal Calorie Helper — Groq AI Agent")
    print("Informational only. Type 'quit' to exit.")

    agent = MealCalorieAgent()

    if agent.client is None:
        raise SystemExit(
            "\nGroq is not configured. Add GROQ_API_KEY to .env and try again."
        )

    while True:
        try:
            user_text = input("\nYou: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nExiting.")
            break

        if user_text.lower() in {"quit", "exit"}:
            break
        if not user_text:
            continue

        try:
            result = agent.run(user_text)
            print(f"\nAgent: {result['answer']}")
            print_trace(result["trace"])
        except Exception as exc:
            print(f"\nAgent error: {exc}")


if __name__ == "__main__":
    main()
