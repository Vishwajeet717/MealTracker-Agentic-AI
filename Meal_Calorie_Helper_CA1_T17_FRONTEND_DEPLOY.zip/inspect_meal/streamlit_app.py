"""Deployment entrypoint for Streamlit Community Cloud."""

from app.ui import *  # noqa: F401,F403,E402
