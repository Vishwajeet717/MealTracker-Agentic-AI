# CSE476 CA1 — T17 Meal Calorie Helper

The Meal Calorie Helper is an LLM-driven agent for tracking a day's meals against an informational calorie budget. The two required assignment tools are `lookup_calories(food)` and `add_meal(food)`. The Groq LLM chooses when to call the tools, receives their results, and can continue for another step before producing the final answer.

Application memory stores today's calorie budget and meals, and the agent receives that memory again on later turns and after tool execution. The agent accepts normal meal, food, calorie, and simple nutrition questions, while clearly rejecting unrelated requests. A user can ask whether a planned snack fits, add foods they actually ate, review today's meals, or ask general food questions.

One honest limitation is that calorie values are estimates, not precise measurements. When the exact food is not in the local educational table, `lookup_calories` uses a clearly labeled heuristic/generic estimate rather than failing a normal food request or inventing a false exact value. Irrelevant non-food requests are the cases intentionally rejected by the application.

## Local setup

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env`:

```env
GROQ_API_KEY=your_groq_api_key
GROQ_MODEL=openai/gpt-oss-120b
```

Run tests:

```powershell
python -m pytest
```

Run the CLI:

```powershell
python main.py
```

Run the notebook:

```powershell
jupyter notebook notebooks/CA1_Meal_Calorie_Helper.ipynb
```

Run the frontend:

```powershell
streamlit run streamlit_app.py
```

## Deployment

The intended deployment target is Streamlit Community Cloud. Push this repository to GitHub, create a Community Cloud app using `streamlit_app.py` as the entrypoint, then add `GROQ_API_KEY` and `GROQ_MODEL` under the app's Secrets/Advanced settings. Do not commit `.env` or any secret key.

Streamlit Community Cloud currently deploys from GitHub repositories, supports configuring secrets during deployment, and serves deployed apps on a `streamlit.app` subdomain.

## CA1 evidence

- **Two required tools:** `lookup_calories(food)` and `add_meal(food)`.
- **Plan–act loop:** `app/agent.py` sends tool schemas to Groq, executes the returned tool call, appends the result, refreshes memory, and calls the model again.
- **Memory:** `app/memory.py` stores today's meals and budget; `app/agent.py` injects that state into later turns.
- **Trace:** The CLI, notebook, and frontend expose the agent/tool/memory sequence.
